"""
File: target.py
Author: Ali Cope

Contains Target class and three derived targets; Strong, Standard, and Safe
"""

import arcade
import math
import random
from flying import Flying

# These are Global constants to use throughout the game
TARGET_RADIUS = 20
TARGET_COLOR = arcade.color.CARROT_ORANGE
TARGET_SAFE_COLOR = arcade.color.AIR_FORCE_BLUE
TARGET_SAFE_RADIUS = 15
SCREEN_HEIGHT = 500

class Target(Flying):
    """
    Creates a target class with the following
    radius : float
    life : int
    score : int
    bonus : int
    +__init__()
    +hit() : int

    it will inheriate from flying:
    center : Point
    velocity : Velocity
    alive : Boolean
    +advance() : None
    +is_off_screen(screen_width, screen_height) : Boolean

    and will override the following inherited from flying
    +draw() : None
    """
    def __init__(self):
        #call the base class to set up our point and velocity
        super().__init__()
        #add radius
        self.radius = float(TARGET_RADIUS)
        #start the target randomly on the top half of the screen
        self.center.y = random.uniform(SCREEN_HEIGHT/2, SCREEN_HEIGHT)
        #start velocity randomly for dx between 1 and 5
        self.velocity.dx = random.uniform(1,5)
        #start velocity randomly for dy between -2 and 5
        self.velocity.dy = random.uniform(-2, 5)
        #standard targets can survive 1 hit
        self.life = 1
        # you get one point per hit
        self.score = 1
        # standard targets gets no bonus points for being destroyed
        self.bonus = 0

    def hit(self):
        """
        hit class, returns point value for a hit and kills target
        """
        self.life -= 1
        total_score = 1
        if self.life == 0:
            self.alive = False
            total_score += self.bonus
        return total_score

    def draw(self):
        """
        override the draw function in flying class
        """
        arcade.draw_circle_filled(self.center.x, self.center.y, self.radius, TARGET_COLOR)

class Strong(Target):
    """
    Creates a Strong class with the following
    +__init__()

    it will inheriate from Target:
    center : Point
    velocity : Velocity
    radius : float
    alive : Boolean
    +advance() : None
    +is_off_screen(screen_width, screen_height) : Boolean
    +hit() : int

    and will override the following inherited from target
    life : int
    score : int
    bonus : int
    +draw() : None
    """
    def __init__(self):
        #call the base class to set up our point and velocity
        super().__init__()
        #start velocity randomly for dx between 1 and 3 (slower than normal target)
        self.velocity.dx = random.uniform(1,3)
        #start velocity randomly for dy between -2 and 3 (slower than normal target)
        self.velocity.dy = random.uniform(-2, 3)
        #strong targets can survive 3 hit
        self.life = 3
        # strong targets gets 4 bonus points for being destroyed
        self.bonus = 4

    def draw(self):
        """
        override the draw function in flying class
        """
        #method provided https://content.byui.edu/file/856c5360-ff89-4409-a7ae-bca07f06f19c/1/week06/skeet.html
        arcade.draw_circle_outline(self.center.x, self.center.y, self.radius, TARGET_COLOR)
        text_x = self.center.x - (self.radius / 2)
        text_y = self.center.y - (self.radius / 2)
        arcade.draw_text(repr(self.life), text_x, text_y, TARGET_COLOR, font_size=20)

class Safe(Target):
    """
    Creates a Strong class with the following
    +__init__()

    it will inheriate from Target:
    center : Point
    velocity : Velocity
    alive : Boolean
    life : int
    +advance() : None
    +is_off_screen(screen_width, screen_height) : Boolean
    +hit() : int

    and will override the following inherited from target
    radius : float
    score : int
    bonus : int
    +draw() : None
    """
    def __init__(self):
        #call the base class to set up our point and velocity
        super().__init__()
        #set safe radius
        self.radius = TARGET_SAFE_RADIUS
        #no points for hitting safe target
        self.score = 0
        # safe targets have -10 penelty for being destroyed
        self.bonus = -10

    def draw(self):
        """
        override the draw function in flying class
        """
        arcade.draw_rectangle_filled(self.center.x, self.center.y, self.radius, self.radius, TARGET_SAFE_COLOR)
